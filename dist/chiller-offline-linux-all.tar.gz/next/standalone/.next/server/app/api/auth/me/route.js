var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__1e4ce7c1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_97ac7615.js")
R.m(93025)
module.exports=R.m(93025).exports
