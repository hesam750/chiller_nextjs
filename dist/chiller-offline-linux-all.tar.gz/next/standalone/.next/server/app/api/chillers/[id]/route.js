var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chillers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2e1c6864._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__9d471fec._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_chillers_[id]_route_actions_ae775ba8.js")
R.m(55593)
module.exports=R.m(55593).exports
