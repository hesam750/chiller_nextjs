var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chiller-control/route.js")
R.c("server/chunks/[externals]__150a8abd._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_ff798c11.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_chiller-control_route_actions_38b4cdb7.js")
R.m(25789)
module.exports=R.m(25789).exports
