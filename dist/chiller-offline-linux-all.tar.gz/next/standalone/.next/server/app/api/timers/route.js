var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/timers/route.js")
R.c("server/chunks/[root-of-the-server]__899c453a._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__9d471fec._.js")
R.c("server/chunks/_next-internal_server_app_api_timers_route_actions_f1b083ce.js")
R.m(97483)
module.exports=R.m(97483).exports
