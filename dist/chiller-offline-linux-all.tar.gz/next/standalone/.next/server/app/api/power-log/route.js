var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/power-log/route.js")
R.c("server/chunks/[root-of-the-server]__6f42db05._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__9d471fec._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_power-log_route_actions_bf955dc9.js")
R.m(90274)
module.exports=R.m(90274).exports
