var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chillers/route.js")
R.c("server/chunks/[root-of-the-server]__1a3a028e._.js")
R.c("server/chunks/_3adbf0dd._.js")
R.c("server/chunks/[root-of-the-server]__9d471fec._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_chillers_route_actions_efaaf254.js")
R.m(81361)
module.exports=R.m(81361).exports
