globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f4a1baff021332e7.js",
    "static/chunks/dce1ee0e89ee93db.js",
    "static/chunks/cc759f7c2413b7ff.js",
    "static/chunks/3d7d43ca4e63e211.js",
    "static/chunks/turbopack-6d935f7a20975b69.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];