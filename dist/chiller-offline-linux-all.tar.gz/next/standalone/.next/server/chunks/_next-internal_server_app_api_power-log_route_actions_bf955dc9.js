module.exports=[71003,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_power-log_route_actions_bf955dc9.js.map