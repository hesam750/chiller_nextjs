module.exports=[19535,e=>e.a(async(a,t)=>{try{let a=await e.y("@prisma/client-2c3a283f134fdcb6/runtime/query_compiler_bg.sqlite.wasm-base64.mjs");e.n(a),t()}catch(e){t(e)}},!0)];

//# sourceMappingURL=2e4a4_%40prisma_client_runtime_query_compiler_bg_sqlite_wasm-base64_mjs_069a3cf6._.js.map